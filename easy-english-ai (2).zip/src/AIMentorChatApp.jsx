import React, { useState, useEffect, useRef } from "react";

const MENTORS = [
  {
    id: "mentor_grammar",
    name: "Lina (Grammar Guru)",
    short: "Clear explanations for grammar, sentence structure, and writing.",
    systemPrompt:
      "You are Lina, a patient English grammar teacher. Provide simple explanations, correct mistakes, and give short exercises. Offer examples and short drills appropriate to the learner's level.",
  },
  {
    id: "mentor_conversation",
    name: "James (Conversation Coach)",
    short: "Real-life speaking practice, prompts, and feedback.",
    systemPrompt:
      "You are James, an encouraging conversation coach. Simulate real-life dialogues, ask follow-up questions, correct common speaking mistakes, and suggest pronunciation tips. Keep turns short and interactive.",
  },
  {
    id: "mentor_vocabulary",
    name: "Ayesha (Vocabulary Builder)",
    short: "Build vocabulary with spaced repetition and context.",
    systemPrompt:
      "You are Ayesha, a vocabulary coach. Teach words with definitions, example sentences, synonyms, antonyms, and short quizzes. Use spaced-repetition suggestions and categorize words by topic and frequency.",
  },
  {
    id: "mentor_exam",
    name: "Tom (Exam Prep - IELTS/TOEFL)",
    short: "Strategies & practice for English proficiency tests.",
    systemPrompt:
      "You are Tom, an exam preparation mentor. Provide test strategies, timed practice tasks, sample answers, and scoring tips for IELTS and TOEFL sections. Offer step-by-step feedback on essays and speaking samples.",
  },
];

const SAMPLE_LESSON = {
  id: "a1_grammar_01",
  level: "A1",
  title: "Present Simple: Affirmative Sentences",
  content:
    "Use the present simple to talk about habits and routines. Structure: Subject + base verb (+ s/es for he/she/it). Example: I eat breakfast at 7am.",
  exercises: [
    { type: "fill_blank", prompt: "I ___ (go) to school.", answer: "go" },
    { type: "short_answer", prompt: "Write 1 sentence about your daily routine.", answer: null },
    { type: "mcq", prompt: "Choose correct verb form", choices: ["go", "goes", "going"], answer: "go" },
  ],
};

function VocabSRS({ namespace = "default_vocab" }) {
  const [cards, setCards] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("vocab_" + namespace)) || sampleCards();
    } catch (e) {
      return sampleCards();
    }
  });
  const [index, setIndex] = useState(0);

  function sampleCards() {
    return [
      { id: 1, word: "arrive", def: "to reach a place", example: "He arrived at 9am.", box: 1, nextReview: Date.now() },
      { id: 2, word: "borrow", def: "to take something temporarily", example: "Can I borrow your pen?", box: 1, nextReview: Date.now() },
    ];
  }

  useEffect(() => {
    localStorage.setItem("vocab_" + namespace, JSON.stringify(cards));
  }, [cards, namespace]);

  function markResult(cardId, result) {
    setCards((prev) =>
      prev.map((c) => {
        if (c.id !== cardId) return c;
        let box = c.box || 1;
        if (result === "again") box = Math.max(1, box - 1);
        if (result === "good") box = Math.min(5, box + 1);
        if (result === "easy") box = Math.min(5, box + 2);
        const interval = [0, 1, 3, 7, 14, 30][box] || 1;
        return { ...c, box, nextReview: Date.now() + interval * 24 * 3600 * 1000 };
      })
    );
    setIndex((i) => Math.min(i + 1, cards.length - 1));
  }

  const due = cards.filter((c) => c.nextReview <= Date.now());
  const current = due[index] || cards[index] || cards[0];

  return (
    <div style={{padding:12,borderRadius:8,background:'#fff',border:'1px solid #e5e7eb'}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
        <div style={{fontWeight:600}}>Vocabulary SRS</div>
        <div style={{fontSize:12,color:'#6b7280'}}>Due: {due.length}</div>
      </div>

      <div>
        <div style={{fontSize:18,fontWeight:500}}>{current.word}</div>
        <div style={{fontSize:13,color:'#4b5563'}}>{current.def}</div>
        <div style={{fontSize:13,fontStyle:'italic',marginTop:6}}>Example: {current.example}</div>
      </div>

      <div style={{marginTop:12,display:'flex',gap:8}}>
        <button onClick={() => markResult(current.id, "again")} style={{padding:'6px 10px',borderRadius:6,border:'1px solid #d1d5db'}}>Again</button>
        <button onClick={() => markResult(current.id, "good")} style={{padding:'6px 10px',borderRadius:6,border:'1px solid #d1d5db'}}>Good</button>
        <button onClick={() => markResult(current.id, "easy")} style={{padding:'6px 10px',borderRadius:6,border:'1px solid #d1d5db'}}>Easy</button>
      </div>

      <div style={{marginTop:12,fontSize:12,color:'#6b7280'}}>Manage cards in localStorage or extend to sync to DB for multi-device use.</div>
    </div>
  );
}

function LessonViewer({ lesson, sendToAI }) {
  const [answers, setAnswers] = useState({});
  const [aiFeedback, setAiFeedback] = useState(null);

  if (!lesson) return <div style={{padding:12}}>Select a lesson to view.</div>;

  async function submitExercise(ex) {
    if (ex.type === "fill_blank") {
      const user = answers[ex.prompt] || "";
      const correct = ex.answer;
      const ok = user.trim().toLowerCase() === correct.trim().toLowerCase();
      setAiFeedback(ok ? "Correct!" : `Not quite — expected: ${correct}`);
    } else if (ex.type === "short_answer") {
      setAiFeedback("Checking...");
      const conv = [{ role: "user", content: `Please review this answer: ${answers[ex.prompt] || ""}` }];
      try {
        const res = await sendToAI({ mentorId: "mentor_grammar", conversation: conv });
        setAiFeedback(res);
      } catch (e) {
        setAiFeedback("AI feedback failed — check backend.");
      }
    } else if (ex.type === "mcq") {
      const user = answers[ex.prompt] || "";
      setAiFeedback(user === ex.answer ? "Correct!" : `Not correct — answer: ${ex.answer}`);
    }
  }

  return (
    <div style={{padding:12,borderRadius:8,background:'#fff',border:'1px solid #e5e7eb'}}>
      <h3 style={{fontWeight:600,fontSize:16}}>{lesson.title}</h3>
      <div style={{fontSize:13,color:'#6b7280',marginBottom:8}}>Level: {lesson.level}</div>
      <div style={{marginBottom:12}}>{lesson.content}</div>

      <div>
        {lesson.exercises?.map((ex, i) => (
          <div key={i} style={{marginBottom:12}}>
            <div style={{fontWeight:600}}>Exercise {i + 1}: {ex.type}</div>

            {ex.type === "fill_blank" && (
              <div>
                <div style={{marginBottom:6}}>{ex.prompt}</div>
                <input
                  value={answers[ex.prompt] || ""}
                  onChange={(e) => setAnswers((a) => ({ ...a, [ex.prompt]: e.target.value }))}
                  style={{width:'100%',padding:8,borderRadius:6,border:'1px solid #d1d5db'}}
                />
                <div style={{marginTop:8}}>
                  <button onClick={() => submitExercise(ex)} style={{padding:'6px 10px',borderRadius:6,background:'#4f46e5',color:'#fff'}}>Submit</button>
                </div>
              </div>
            )}

            {ex.type === "short_answer" && (
              <div>
                <textarea
                  value={answers[ex.prompt] || ""}
                  onChange={(e) => setAnswers((a) => ({ ...a, [ex.prompt]: e.target.value }))}
                  style={{width:'100%',padding:8,borderRadius:6,border:'1px solid #d1d5db'}}
                />
                <div style={{marginTop:8}}>
                  <button onClick={() => submitExercise(ex)} style={{padding:'6px 10px',borderRadius:6,background:'#4f46e5',color:'#fff'}}>Ask AI for feedback</button>
                </div>
              </div>
            )}

            {ex.type === "mcq" && (
              <div>
                {ex.choices.map((c, idx) => (
                  <label key={idx} style={{display:'block'}}>
                    <input
                      type="radio"
                      name={`mcq_${i}`}
                      onChange={() => setAnswers((a) => ({ ...a, [ex.prompt]: c }))}
                    /> {c}
                  </label>
                ))}
                <div style={{marginTop:8}}>
                  <button onClick={() => submitExercise(ex)} style={{padding:'6px 10px',borderRadius:6,background:'#4f46e5',color:'#fff'}}>Check</button>
                </div>
              </div>
            )}

          </div>
        ))}

        {aiFeedback && (
          <div style={{marginTop:12,padding:8,borderRadius:6,background:'#fff',border:'1px solid #e5e7eb'}}>
            <div style={{fontWeight:600}}>AI feedback</div>
            <div style={{marginTop:6,whiteSpace:'pre-wrap'}}>{aiFeedback}</div>
          </div>
        )}
      </div>
    </div>
  );
}

function AudioRecorder({ onTranscription }) {
  const [rec, setRec] = useState(false);
  const [media, setMedia] = useState(null);
  const [transcript, setTranscript] = useState("");
  const chunksRef = useRef([]);
  const recorderRef = useRef(null);

  async function start() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      recorderRef.current = mr;
      chunksRef.current = [];
      mr.ondataavailable = (e) => chunksRef.current.push(e.data);
      mr.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        const fd = new FormData();
        fd.append("file", blob, "speech.webm");
        try {
          // mock STT response in browser preview
          const reader = new FileReader();
          reader.onload = () => {
            // fake transcription: show length in seconds
            const approxSeconds = Math.max(1, Math.round(chunksRef.current.length));
            const fake = `Recorded audio (mock) — approx ${approxSeconds} chunks`;
            setTranscript(fake);
            onTranscription && onTranscription(fake);
          };
          reader.readAsDataURL(blob);
        } catch (e) {
          setTranscript("STT failed — implement /api/stt");
        }
      };
      mr.start();
      setRec(true);
      setMedia(stream);
    } catch (err) {
      console.error("Microphone access denied or unavailable", err);
      setTranscript("Microphone access denied or unavailable");
    }
  }

  function stop() {
    if (recorderRef.current) recorderRef.current.stop();
    if (media) {
      media.getTracks().forEach((t) => t.stop());
      setMedia(null);
    }
    setRec(false);
  }

  return (
    <div style={{padding:12,borderRadius:8,background:'#fff',border:'1px solid #e5e7eb'}}>
      <div style={{fontWeight:600}}>Audio Recorder</div>
      <div style={{marginTop:8}}>
        {!rec ? (
          <button onClick={start} style={{padding:'6px 10px',borderRadius:6,background:'#10b981',color:'#fff'}}>Record</button>
        ) : (
          <button onClick={stop} style={{padding:'6px 10px',borderRadius:6,background:'#ef4444',color:'#fff'}}>Stop</button>
        )}
      </div>
      <div style={{marginTop:8,fontSize:13,color:'#6b7280'}}>Transcription:</div>
      <div style={{marginTop:8,padding:8,borderRadius:6,background:'#fff',border:'1px solid #e5e7eb',minHeight:48}}>{transcript}</div>
    </div>
  );
}

export default function AIMentorChatApp() {
  const [selectedMentor, setSelectedMentor] = useState(MENTORS[0]);
  const [conversations, setConversations] = useState(() => {
    const base = {};
    MENTORS.forEach((m) => {
      base[m.id] = [
        { role: "system", content: m.systemPrompt },
        { role: "assistant", content: `Hi — I'm ${m.name}. How can I help you today?` },
      ];
    });
    return base;
  });
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);
  const [selectedLesson, setSelectedLesson] = useState(SAMPLE_LESSON);

  useEffect(() => {
    scrollToBottom();
  }, [conversations, selectedMentor]);

  function scrollToBottom() {
    if (messagesEndRef.current) messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
  }

  const currentConv = conversations[selectedMentor.id] || [];

  async function handleSend(e) {
    e?.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) return;

    const userMsg = { role: "user", content: trimmed };
    const updated = [...currentConv, userMsg];
    setConversations((prev) => ({ ...prev, [selectedMentor.id]: updated }));
    setInput("");
    setLoading(true);

    try {
      const assistant = await sendToAI({ mentorId: selectedMentor.id, conversation: updated });
      const appended = [...updated, { role: "assistant", content: assistant }];
      setConversations((prev) => ({ ...prev, [selectedMentor.id]: appended }));
    } catch (err) {
      console.error("AI call failed", err);
      const errMsg = { role: "assistant", content: "Sorry — I couldn't reach the AI service. Please try again." };
      setConversations((prev) => ({ ...prev, [selectedMentor.id]: [...updated, errMsg] }));
    } finally {
      setLoading(false);
    }
  }

  async function sendToAI({ mentorId, conversation }) {
    await new Promise((r) => setTimeout(r, 600));
    const lastUser = conversation.slice().reverse().find((m) => m.role === "user");
    const text = lastUser ? lastUser.content.toLowerCase() : "hello";
    if (text.includes("hello") || text.includes("hi")) return `Hello! I'm ${selectedMentor.name}. How can I help with your English today?`;
    if (text.includes("grammar")) return "Let's work on grammar — please paste a sentence you'd like corrected.";
    if (text.includes("speak") || text.includes("pronounce")) return "Try recording a short sentence and I'll give feedback on pronunciation.";
    return "Great — here's a short plan: 1) Clarify the goal, 2) Try a small exercise, 3) Review results. Would you like a detailed example?";
  }

  function handleSelectMentor(m) {
    setSelectedMentor(m);
  }

  function clearConversation() {
    setConversations((prev) => ({ ...prev, [selectedMentor.id]: [
      { role: "system", content: selectedMentor.systemPrompt },
      { role: "assistant", content: `Hi — I'm ${selectedMentor.name}. How can I help you today?` },
    ] }));
  }

  return (
    <div style={{minHeight:'100vh',background:'#f9fafb',display:'flex',flexDirection: 'row'}}>
      <aside style={{width:320,background:'#fff',borderRight:'1px solid #e5e7eb',padding:16,display:'flex',flexDirection:'column',gap:12}}>
        <div>
          <h1 style={{fontSize:20,fontWeight:700}}>Easy to learn English with AI</h1>
          <p style={{color:'#6b7280',fontSize:13}}>Choose a mentor, open a lesson, or practice vocabulary & speaking.</p>
        </div>

        <div style={{display:'flex',flexDirection:'column',gap:8}}>
          {MENTORS.map((m) => (
            <button key={m.id} onClick={() => handleSelectMentor(m)} style={{textAlign:'left',padding:12,borderRadius:8,border:selectedMentor.id===m.id?'1px solid #c7d2fe':'1px solid #eef2ff',background:selectedMentor.id===m.id?'#eef2ff':'transparent'}}>
              <div style={{fontWeight:600}}>{m.name}</div>
              <div style={{fontSize:13,color:'#6b7280'}}>{m.short}</div>
            </button>
          ))}
        </div>

        <div style={{paddingTop:8}}>
          <div style={{marginBottom:8,fontWeight:600}}>Tools</div>
          <div style={{display:'flex',flexDirection:'column',gap:8}}>
            <button onClick={() => setSelectedLesson(SAMPLE_LESSON)} style={{padding:10,borderRadius:8,border:'1px solid #e5e7eb'}}>Open sample lesson</button>
            <button onClick={clearConversation} style={{padding:10,borderRadius:8,border:'1px solid #e5e7eb',color:'#ef4444'}}>Clear conversation</button>
          </div>
        </div>

        <div style={{marginTop:'auto'}}>
          <VocabSRS />
        </div>
      </aside>

      <main style={{flex:1,display:'flex',flexDirection:'column'}}>
        <div style={{padding:16,borderBottom:'1px solid #e5e7eb',background:'#fff',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <div>
            <div style={{fontWeight:700}}>{selectedMentor.name}</div>
            <div style={{fontSize:13,color:'#6b7280'}}>{selectedMentor.short}</div>
          </div>
          <div style={{fontSize:13,color:'#9ca3af'}}>Status: {loading ? 'Thinking...' : 'Ready'}</div>
        </div>

        <div style={{flex:1,padding:16,overflow:'auto'}}>
          <div style={{maxWidth:1100,margin:'0 auto',display:'grid',gridTemplateColumns:'2fr 1fr',gap:16}}>
            <div>
              <div style={{padding:12,borderRadius:8,background:'#fff',border:'1px solid #e5e7eb'}}>
                <div style={{height:320,overflow:'auto'}}>
                  {currentConv.map((m, idx) => {
                    if (m.role === 'system') return null;
                    const isUser = m.role === 'user';
                    return (
                      <div key={idx} style={{marginBottom:16,display:'flex',justifyContent:isUser?'flex-end':'flex-start'}}>
                        <div style={{padding:12,borderRadius:8,maxWidth:'80%',background:isUser?'#4f46e5':'#fff',color:isUser?'#fff':'#111',border:isUser?'none':'1px solid #e5e7eb'}}>
                          <div style={{whiteSpace:'pre-wrap'}}>{m.content}</div>
                          <div style={{fontSize:12,color:'#9ca3af',marginTop:8}}>{isUser ? 'You' : selectedMentor.name}</div>
                        </div>
                      </div>
                    );
                  })}
                  <div ref={messagesEndRef} />
                </div>

                <form onSubmit={handleSend} style={{marginTop:12}}>
                  <div style={{display:'flex',gap:8}}>
                    <input value={input} onChange={(e)=>setInput(e.target.value)} placeholder={`Message ${selectedMentor.name} — e.g. \"Help me with grammar\"`} style={{flex:1,padding:12,borderRadius:8,border:'1px solid #e5e7eb'}} disabled={loading} />
                    <button type="submit" disabled={loading} style={{padding:'8px 12px',borderRadius:8,background:'#4f46e5',color:'#fff'}}>Send</button>
                  </div>
                </form>
              </div>

              <div style={{marginTop:16}}>
                <LessonViewer lesson={selectedLesson} sendToAI={sendToAI} />
              </div>
            </div>

            <div style={{display:'flex',flexDirection:'column',gap:12}}>
              <AudioRecorder onTranscription={(t)=>{ setInput((prev)=> (prev? prev + \"\\n\" + t : t)); }} />

              <div style={{padding:12,borderRadius:8,background:'#fff',border:'1px solid #e5e7eb'}}>
                <div style={{fontWeight:600}}>Quick Tips</div>
                <ul style={{marginTop:8,color:'#6b7280'}}>
                  <li>Use the lesson panel for exercises.</li>
                  <li>Record yourself and get transcription via the STT endpoint (mocked here).</li>
                  <li>Replace `sendToAI` with your backend to enable live AI feedback.</li>
                </ul>
              </div>
            </div>

          </div>
        </div>

      </main>
    </div>
  ); 
}
