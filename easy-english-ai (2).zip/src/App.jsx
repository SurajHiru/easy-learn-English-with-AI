import React from "react";
import AIMentorChatApp from "./AIMentorChatApp.jsx";
export default function App(){ return <AIMentorChatApp /> }